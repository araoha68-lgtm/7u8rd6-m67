// upload.js
// Posts a finished MP4 to a Facebook PAGE (not a personal profile -- Meta
// does not allow API posting to personal timelines) using Meta's Resumable
// Upload API, per https://developers.facebook.com/docs/graph-api/video-uploads/
//
// Needs these environment variables (see README for how to get each one):
//   FB_APP_ID      - your Facebook App's ID
//   FB_USER_TOKEN  - a long-lived USER access token for that app
//   FB_PAGE_ID     - the numeric ID of the Page you're posting to
//   FB_PAGE_TOKEN  - a Page access token for that Page

const fs = require('fs');
const path = require('path');

const API_VERSION = 'v26.0';

async function uploadVideoToPage({ filePath, caption, title }) {
  const { FB_APP_ID, FB_USER_TOKEN, FB_PAGE_ID, FB_PAGE_TOKEN } = process.env;
  const required = { FB_APP_ID, FB_USER_TOKEN, FB_PAGE_ID, FB_PAGE_TOKEN };
  const missing = Object.entries(required).filter(([, v]) => !v).map(([k]) => k);
  if (missing.length) {
    throw new Error(`Missing env vars: ${missing.join(', ')}. See README.md for how to get them.`);
  }

  const stat = fs.statSync(filePath);
  const fileName = path.basename(filePath);

  // --- Step 1: start an upload session (App ID + USER token) ---
  const sessionUrl =
    `https://graph.facebook.com/${API_VERSION}/${FB_APP_ID}/uploads` +
    `?file_name=${encodeURIComponent(fileName)}` +
    `&file_length=${stat.size}` +
    `&file_type=video/mp4` +
    `&access_token=${encodeURIComponent(FB_USER_TOKEN)}`;

  const sessionRes = await fetch(sessionUrl, { method: 'POST' });
  const sessionJson = await sessionRes.json();
  if (!sessionRes.ok || !sessionJson.id) {
    throw new Error(`Step 1 (start session) failed: ${JSON.stringify(sessionJson)}`);
  }
  const uploadSessionId = sessionJson.id; // looks like "upload:XXXXXXXX"

  // --- Step 2: send the file bytes (USER token) ---
  const fileBuffer = fs.readFileSync(filePath);
  const uploadRes = await fetch(`https://graph.facebook.com/${API_VERSION}/${uploadSessionId}`, {
    method: 'POST',
    headers: {
      Authorization: `OAuth ${FB_USER_TOKEN}`,
      file_offset: '0',
      'Content-Type': 'application/octet-stream',
    },
    body: fileBuffer,
  });
  const uploadJson = await uploadRes.json();
  if (!uploadRes.ok || !uploadJson.h) {
    throw new Error(`Step 2 (upload bytes) failed: ${JSON.stringify(uploadJson)}`);
  }
  const handle = uploadJson.h;

  // --- Step 3: publish the video to the Page (PAGE token) ---
  const publishForm = new URLSearchParams();
  publishForm.set('access_token', FB_PAGE_TOKEN);
  publishForm.set('fbuploader_video_file_chunk', handle);
  if (title) publishForm.set('title', title);
  if (caption) publishForm.set('description', caption);

  const publishRes = await fetch(`https://graph-video.facebook.com/${API_VERSION}/${FB_PAGE_ID}/videos`, {
    method: 'POST',
    body: publishForm,
  });
  const publishJson = await publishRes.json();
  if (!publishRes.ok || !publishJson.id) {
    throw new Error(`Step 3 (publish) failed: ${JSON.stringify(publishJson)}`);
  }

  return publishJson.id;
}

module.exports = { uploadVideoToPage };
