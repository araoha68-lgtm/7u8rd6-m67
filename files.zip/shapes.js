// shapes.js
// Every shape is just a JS array of {x,y,z} points, built with math and
// canvas-silhouette sampling -- never a 3D mesh/model file.

const { createCanvas } = require('canvas');

// Draw a white silhouette (holes optionally cut with destination-out) onto a
// transparent canvas, then scatter random points and keep the ones that land
// inside it. Each kept point gets a shallow random depth (z) so the whole
// object reads as a gently rounded volume instead of a flat cutout.
function pointsFromSilhouette(drawFn, W, H, count, zAmp) {
  const mc = createCanvas(W, H);
  const mctx = mc.getContext('2d');
  drawFn(mctx, W, H);
  const data = mctx.getImageData(0, 0, W, H).data;

  const inside = (x, y) => {
    if (x < 0 || x >= W || y < 0 || y >= H) return false;
    return data[(((y | 0) * W) + (x | 0)) * 4 + 3] > 128;
  };

  const pts = [];
  let tries = 0;
  const maxTries = count * 60;
  while (pts.length < count && tries < maxTries) {
    tries++;
    const x = Math.random() * W;
    const y = Math.random() * H;
    if (!inside(x, y)) continue;
    const lx = x - W / 2;
    const ly = y - H / 2;
    const nx = lx / (W / 2);
    const ny = ly / (H / 2);
    const r = Math.min(1, Math.sqrt(nx * nx + ny * ny));
    const dome = Math.cos((r * Math.PI) / 2); // 1 at center, 0 at edge
    const z = (Math.random() * 2 - 1) * zAmp * dome + (Math.random() * 2 - 1) * zAmp * 0.12;
    pts.push({ x: lx, y: ly, z });
  }
  return pts;
}

function skull(size, count = 5200) {
  const W = size, H = Math.round(size * 1.25);
  const rx = W * 0.46, ry = H * 0.42;
  return pointsFromSilhouette((ctx) => {
    const ox = W / 2, oy = H / 2;
    ctx.fillStyle = '#fff';
    ctx.beginPath(); ctx.ellipse(ox, oy - ry * 0.40, rx * 0.90, ry * 0.52, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(ox, oy - ry * 0.02, rx * 0.80, ry * 0.34, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(ox, oy + ry * 0.32, rx * 0.52, ry * 0.28, 0, 0, Math.PI * 2); ctx.fill();
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath(); ctx.ellipse(ox - rx * 0.35, oy - ry * 0.08, rx * 0.24, ry * 0.19, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.ellipse(ox + rx * 0.35, oy - ry * 0.08, rx * 0.24, ry * 0.19, 0, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath();
    ctx.moveTo(ox, oy + ry * 0.07);
    ctx.lineTo(ox - rx * 0.09, oy + ry * 0.26);
    ctx.lineTo(ox + rx * 0.09, oy + ry * 0.26);
    ctx.closePath(); ctx.fill();
    for (let i = -2; i <= 2; i++) {
      ctx.beginPath();
      ctx.rect(ox + i * rx * 0.13 - rx * 0.025, oy + ry * 0.56, rx * 0.05, ry * 0.10);
      ctx.fill();
    }
    ctx.globalCompositeOperation = 'source-over';
  }, W, H, count, size * 0.09);
}

function star(size, count = 5200) {
  const W = size, H = size;
  return pointsFromSilhouette((ctx) => {
    const ox = W / 2, oy = H / 2, spikes = 5, outerR = W * 0.46, innerR = W * 0.18;
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    for (let i = 0; i < spikes * 2; i++) {
      const r = i % 2 === 0 ? outerR : innerR;
      const a = (Math.PI / spikes) * i - Math.PI / 2;
      const px = ox + Math.cos(a) * r, py = oy + Math.sin(a) * r;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
  }, W, H, count, size * 0.07);
}

function heart(size, count = 5200) {
  const W = size, H = size;
  return pointsFromSilhouette((ctx) => {
    const ox = W / 2, oy = H * 0.46, s = W * 0.028;
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    for (let t = 0; t <= Math.PI * 2 + 0.01; t += 0.01) {
      const x = 16 * Math.pow(Math.sin(t), 3);
      const y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
      const px = ox + x * s, py = oy - y * s;
      if (t === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();
  }, W, H, count, size * 0.08);
}

// Ring and spiral are built directly as parametric tubes (centerline + small
// circular cross-section swept along it) -- pure trigonometry, no silhouette.

function ring(size, count = 6200) {
  const pts = [];
  const R = size * 0.30, r = size * 0.085;
  for (let i = 0; i < count; i++) {
    const u = Math.random() * Math.PI * 2;
    const v = Math.random() * Math.PI * 2;
    const x = (R + r * Math.cos(v)) * Math.cos(u);
    const y = r * Math.sin(v);
    const z = (R + r * Math.cos(v)) * Math.sin(u);
    pts.push({ x, y, z });
  }
  return pts;
}

function spiral(size, count = 6200) {
  const pts = [];
  const turns = 4.2, topR = size * 0.30, botR = size * 0.03, tubeR = size * 0.045, H = size * 0.85;
  for (let i = 0; i < count; i++) {
    const t = Math.random();
    const ang = t * turns * Math.PI * 2;
    const rad = topR + (botR - topR) * t;
    const cx0 = Math.cos(ang) * rad, cz0 = Math.sin(ang) * rad;
    const cy0 = -H / 2 + t * H;
    const v = Math.random() * Math.PI * 2;
    pts.push({
      x: cx0 + Math.cos(v) * tubeR,
      y: cy0 + Math.sin(v) * tubeR * 0.6,
      z: cz0 + Math.sin(v) * tubeR,
    });
  }
  return pts;
}

module.exports = { skull, star, heart, ring, spiral };
