# illusion-bot

Generates a random "ambiguous rotation" illusion video (a skull, star, heart,
ring, or spiral, spinning with an ambiguous direction, like the classic
spinning-dancer illusion) and posts it to a Facebook Page — fully in the
cloud, on a schedule, for free, with no computer required.

**How it works:** `shapes.js` builds each object as a cloud of a few
thousand points using plain math (no 3D model files). `render.js` rotates
that point cloud and draws it frame by frame with `canvas`, bakes in a
caption, and calls `ffmpeg` to assemble the frames into an MP4. `upload.js`
posts that MP4 to your Facebook Page. `run.js` ties it together, picking a
random shape/style each time. `.github/workflows/post.yml` runs `run.js` on
a timer using GitHub's free Actions runners — nothing needs to stay on at
your end.

You do the setup below once. After that it posts by itself.

---

## Part A — Create a Facebook Developer App

You said you already have a Facebook **Page** — good, that's the required
piece (Facebook's API can only post to Pages, never to a personal profile).
Now you need an "app," which is just Meta's name for a set of API
credentials.

1. On your phone, open a browser (not the Facebook app) and go to
   **developers.facebook.com**. Log in with the account that manages your Page.
2. Tap **My Apps → Create App**.
3. Pick **Business** as the app type (or the closest option to it if the
   wording differs slightly). Give it any name, e.g. "Illusion Poster."
4. Once it's created, open **Settings → Basic**. Copy two things from here:
   - **App ID** → this is your `FB_APP_ID`
   - **App Secret** (tap "Show") → you'll need this once, in Part B

You do **not** need to submit this app for Meta's App Review. Review is only
required for apps that act on *other* people's Pages. Since you're only
posting to your own Page, Development Mode is enough forever.

---

## Part B — Get your tokens

1. Go to **developers.facebook.com/tools/explorer** (Graph API Explorer).
2. Top right: pick your app from the dropdown.
3. Click **Get Token → Get User Access Token**. In the permissions list that
   pops up, check: `pages_show_list`, `pages_manage_posts`,
   `pages_read_engagement` — then generate. Copy the token it gives you
   (this one is short-lived, just for the next step).
4. **Exchange it for a long-lived token.** Paste this into your browser's
   address bar, replacing the three placeholders with your App ID, App
   Secret, and the short-lived token from step 3:

   ```
   https://graph.facebook.com/v26.0/oauth/access_token?grant_type=fb_exchange_token&client_id=YOUR_APP_ID&client_secret=YOUR_APP_SECRET&fb_exchange_token=YOUR_SHORT_TOKEN
   ```

   The page that loads shows a new `access_token` — that's your
   `FB_USER_TOKEN` (lasts about 60 days; see **Maintenance** below).

5. **Get your Page ID and Page token.** Paste this into the browser, with
   your long-lived user token from step 4:

   ```
   https://graph.facebook.com/v26.0/me/accounts?access_token=YOUR_FB_USER_TOKEN
   ```

   This lists every Page you manage. Find yours and copy its `"id"` (→
   `FB_PAGE_ID`) and its `"access_token"` (→ `FB_PAGE_TOKEN`).

You should now have four values: `FB_APP_ID`, `FB_USER_TOKEN`, `FB_PAGE_ID`,
`FB_PAGE_TOKEN`.

---

## Part C — Put this on GitHub (free, runs in the cloud)

1. Go to **github.com** and create a free account if you don't have one.
2. Tap **+ → New repository**. Name it e.g. `illusion-bot`, set it to
   **Private**, create it.
3. Use **Add file → Upload files** to upload every file from this project,
   keeping the same names and folders — including the `.github/workflows/`
   folder with `post.yml` inside it (most mobile browsers let you drag the
   whole folder in; if not, use "create new file" and type the full path
   `.github/workflows/post.yml` as the file name, which creates the folder
   automatically).
4. Go to the repo's **Settings → Secrets and variables → Actions**. Tap
   **New repository secret** four times, adding:
   `FB_APP_ID`, `FB_USER_TOKEN`, `FB_PAGE_ID`, `FB_PAGE_TOKEN` — pasting in
   the values from Part B.
5. Go to the **Actions** tab. GitHub may ask you to confirm you want
   workflows enabled — accept. You'll see "Post illusion to Facebook" listed.

That's the entire setup. It will now run automatically every day at 15:00
UTC and post a fresh illusion to your Page.

---

## Test it right now

In the **Actions** tab, click into "Post illusion to Facebook" and use the
**Run workflow** button to trigger it immediately instead of waiting for the
schedule. Watch it run (takes 2–4 minutes); a green check means it posted.
If it fails, click into the run to see which step errored — the most common
cause is a typo in one of the four secrets.

---

## Customizing

- **Posting frequency:** edit the `cron:` line in
  `.github/workflows/post.yml`. It's `minute hour day month weekday` in UTC.
  `0 15 * * *` = daily at 15:00 UTC. `0 15 */3 * *` = every 3 days.
- **Captions:** edit the `CAPTIONS` object in `run.js`.
- **Which shapes/colors are used:** edit `PALETTES_BY_SHAPE` in `run.js`, or
  add a new shape function in `shapes.js` following the existing pattern.
- **Video length/speed:** `SECONDS` and `FPS` at the top of `render.js`.

## Maintenance

`FB_USER_TOKEN` expires roughly every 60 days (Meta's limit on user tokens,
not something this code controls). When it does, the workflow will start
failing. Repeat step 4 of Part B to get a fresh one and update the
`FB_USER_TOKEN` secret. If you want a token that never expires, the next
step up is converting to a **System User token** via Meta Business Suite —
ask me if you want a walkthrough for that later.
