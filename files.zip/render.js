// render.js
// Turns a shape name + palette + caption into a finished vertical MP4.
// No 3D engine: canvas 2D + plain rotation math (see README for the theory).

const { createCanvas, registerFont } = require('canvas');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const shapes = require('./shapes');

try {
  registerFont('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', { family: 'CaptionFont' });
} catch (e) {
  console.warn('Could not register DejaVu font, falling back to default:', e.message);
}

const W = 1080, H = 1920;
const FPS = 30;
const SECONDS = 9;
const FOCAL = 1400;

// Hue-by-vertical-position palettes. `null` means "grayscale speckle" instead
// of a hue. Colour is always fixed to each point's OWN coordinate, never to
// the live rotation angle -- that's what keeps the spin direction ambiguous.
const PALETTES = {
  rainbow: (t) => (((110 - t * 230) % 360) + 360) % 360,
  ice: (t) => 185 + t * 55,
  fire: (t) => 12 + t * 42,
  mono: () => null,
};

function colorPoints(points, paletteName) {
  const ys = points.map((p) => p.y);
  const topY = Math.min(...ys), botY = Math.max(...ys);
  const paletteFn = PALETTES[paletteName] || PALETTES.rainbow;
  for (const p of points) {
    const t = (p.y - topY) / ((botY - topY) || 1);
    const hue = paletteFn(t);
    p.gray = hue === null;
    p.hue = hue;
    p.lightness = 55 + Math.random() * 35;
    p.size = 1.1 + Math.random() * 1.7;
    p.alpha = 0.55 + Math.random() * 0.45;
  }
}

function wrapText(ctx, text, maxWidth) {
  const words = text.split(' ');
  const lines = [];
  let line = '';
  for (const w of words) {
    const test = line ? line + ' ' + w : w;
    if (ctx.measureText(test).width > maxWidth && line) {
      lines.push(line);
      line = w;
    } else {
      line = test;
    }
  }
  if (line) lines.push(line);
  return lines;
}

function renderVideo({ shapeName, palette = 'rainbow', caption = '', outPath, tmpDir }) {
  const gen = shapes[shapeName];
  if (!gen) throw new Error(`Unknown shape "${shapeName}". Options: ${Object.keys(shapes).join(', ')}`);

  fs.mkdirSync(tmpDir, { recursive: true });

  const size = 620;
  const points = gen(size);
  colorPoints(points, palette);

  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  const totalFrames = FPS * SECONDS;
  const cx = W / 2, cy = H * 0.58;

  for (let f = 0; f < totalFrames; f++) {
    const theta = (f / totalFrames) * Math.PI * 2;
    const cosT = Math.cos(theta), sinT = Math.sin(theta);

    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, W, H);

    const proj = new Array(points.length);
    for (let i = 0; i < points.length; i++) {
      const p = points[i];
      const x2 = p.x * cosT - p.z * sinT;
      const z2 = p.x * sinT + p.z * cosT;
      const scale = FOCAL / (FOCAL + z2);
      proj[i] = {
        sx: cx + x2 * scale,
        sy: cy + p.y * scale,
        z2,
        size: p.size * scale,
        alpha: p.alpha,
        gray: p.gray,
        hue: p.hue,
        lightness: p.lightness,
      };
    }
    proj.sort((a, b) => b.z2 - a.z2); // farthest first, nearest last (on top)

    for (const q of proj) {
      ctx.beginPath();
      ctx.fillStyle = q.gray
        ? `hsla(0,0%,${q.lightness}%,${q.alpha})`
        : `hsla(${q.hue},85%,58%,${q.alpha})`;
      ctx.arc(q.sx, q.sy, Math.max(0.5, q.size), 0, Math.PI * 2);
      ctx.fill();
    }

    if (caption) {
      ctx.textAlign = 'center';
      ctx.font = '600 54px CaptionFont, sans-serif';
      ctx.fillStyle = 'rgba(255,255,255,0.94)';
      const lines = wrapText(ctx, caption, W * 0.82);
      let ty = H * 0.14;
      for (const line of lines) {
        ctx.fillText(line, cx, ty);
        ty += 64;
      }
    }

    fs.writeFileSync(path.join(tmpDir, `f${String(f).padStart(4, '0')}.png`), canvas.toBuffer('image/png'));
  }

  execSync(
    `ffmpeg -y -framerate ${FPS} -i "${tmpDir}/f%04d.png" -c:v libx264 -pix_fmt yuv420p -movflags +faststart "${outPath}"`,
    { stdio: 'inherit' }
  );

  fs.rmSync(tmpDir, { recursive: true, force: true });
  return outPath;
}

module.exports = { renderVideo, PALETTES, SHAPE_NAMES: Object.keys(shapes) };
