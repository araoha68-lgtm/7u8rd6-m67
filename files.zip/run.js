// run.js — the entry point. Each run: pick something random, render it,
// post it. Run with `node run.js --no-upload` to only test the rendering.

const path = require('path');
const fs = require('fs');
const { renderVideo, SHAPE_NAMES } = require('./render');
const { uploadVideoToPage } = require('./upload');

const CAPTIONS = {
  skull: 'Can you reverse the skull with your mind?',
  star: 'Can you reverse the star spin with your mind?',
  heart: 'Can you reverse the heart with your mind?',
  ring: 'Can you reverse the spin with your mind?',
  spiral: 'Can you reverse the spin with your mind?',
};

const PALETTES_BY_SHAPE = {
  skull: ['mono', 'ice'],
  star: ['rainbow', 'fire'],
  heart: ['rainbow', 'fire'],
  ring: ['rainbow', 'mono'],
  spiral: ['rainbow', 'ice'],
};

const HASHTAGS = '#illusion #opticalillusion #mindbender #satisfying';

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

async function main() {
  const noUpload = process.argv.includes('--no-upload');

  const shapeName = pick(SHAPE_NAMES);
  const palette = pick(PALETTES_BY_SHAPE[shapeName] || ['rainbow']);
  const caption = CAPTIONS[shapeName] || 'Can you reverse this with your mind?';

  const outDir = path.join(__dirname, 'output');
  fs.mkdirSync(outDir, { recursive: true });
  const stamp = Date.now();
  const outPath = path.join(outDir, `illusion-${stamp}.mp4`);
  const tmpDir = path.join(__dirname, `.tmp-${stamp}`);

  console.log(`Rendering "${shapeName}" / ${palette}...`);
  renderVideo({ shapeName, palette, caption, outPath, tmpDir });
  console.log(`Rendered: ${outPath}`);

  if (noUpload) {
    console.log('--no-upload passed: skipping the Facebook post.');
    return;
  }

  console.log('Uploading to Facebook...');
  const videoId = await uploadVideoToPage({
    filePath: outPath,
    caption: `${caption}\n\n${HASHTAGS}`,
  });
  console.log(`Posted! Facebook video id: ${videoId}`);
}

main().catch((err) => {
  console.error('FAILED:', err);
  process.exit(1);
});
